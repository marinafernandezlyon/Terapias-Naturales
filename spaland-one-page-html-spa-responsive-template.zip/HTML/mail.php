<?php
// Where will you get the forms' results?
define("CONTACT_FORM", 'info@yourdomain.com');
?>
